


function validation(){
   
   let fname=document.forms["regForm"]["fname"];
   let lname=document.forms["regForm"]["lname"];
   let mail=document.forms["regForm"]["mail"];

    if (fname.value=="") {

    	window.alert("please enter first name");
    	fname.focus();
    	return false;
    }if (lname.value=="") {
    	 window.alert("please enter the second name");
    	 lname.focus();
    	 return false;
    }if (mail.value=="") {

    	window.alert("please enter the email");
    	mail.focus();
    	return false;
    }


    return true;
}


function validating(){


    let fname=document.forms["regForms"]["fname"];
    let lname=document.forms["regForms"]["lname"];
    if (fname.value=="") {

         window.alert("please enter first name");
         fname.focus();
         return false;

    }
    if (lname.value=="") {
        window.alert("please enter the second name");
        lname.focus();
        return false;
    }

    return true;
}

 
