<!DOCTYPE html>
<html>
<head>
	<title></title>
	<link rel="stylesheet" type="text/css" href="/css/welcome.css">
	<script type="text/javascript" src="/js/index.js"></script>
</head>
<body>
   <form  name="regForms"  action="/signingin"  onsubmit="return validating()" method="POST" >
   	{{ csrf_field() }}
   	<label>FNAME:</label><br>
   	<input type="" name="fname"><br>
   	<label>LNAME:</label><br>
   	<input type="" name="lname"><br>
   	<button>SAVE</button><br>
   </form>
</body>
</html>