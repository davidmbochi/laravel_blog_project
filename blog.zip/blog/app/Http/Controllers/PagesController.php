<?php
namespace App\Http\Controllers;

use App\register;

class PagesController extends Controller{
   public function home()
   {
    return view('welcome');
    }
    public function about(){
    return view('about');
    }
    public function insert(){
     $insert= new register();

     $insert->fname=request('fname');

     $insert->lname=request('lname');
     
     $insert->email=request('mail'); 

     $insert->save();

     return 'data saved successfully';

    }

    public function redirect(){

    	return view('signin');
    }
    public function validatelogin(){
    	
    	return 'signed in successfully';
    }
}
